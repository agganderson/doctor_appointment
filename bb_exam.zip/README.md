# doctor_appointment
Application to using MongoDB, Express, Javascript, Node and Angular. User can login, make an appointment, cancel their own appointment.
